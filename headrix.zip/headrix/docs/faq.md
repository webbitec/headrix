# FAQ

**Sticky header doesn't appear?**  
Ensure sticky is enabled in Headrix Settings and your theme calls `wp_body_open()` (fallback provided).

**Primary menu empty?**  
Assign items to "Headrix Primary Menu" in Appearance > Menus.
