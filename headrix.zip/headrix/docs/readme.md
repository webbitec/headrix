# Headrix
Professional Header & Mega Menu Builder for WordPress.

## Features
- Custom header with logo, menu, actions.
- Sticky header and responsive mobile menu.
- Settings panel, Customizer integration, RTL/i18n ready.
