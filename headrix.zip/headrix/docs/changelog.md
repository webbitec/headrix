# Changelog

## 1.0.0
- Initial professional scaffolding, header builder, settings, assets.
