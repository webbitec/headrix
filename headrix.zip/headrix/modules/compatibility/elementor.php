<?php
namespace Headrix\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Elementor {
    // Placeholder: register Elementor widget if Elementor active
    // add_action('elementor/widgets/register', ...);
}
