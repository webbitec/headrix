<?php
namespace Headrix\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Gutenberg {
    // Placeholder: register block for header area
}
