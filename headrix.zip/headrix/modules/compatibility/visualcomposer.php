<?php
namespace Headrix\Compatibility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class VisualComposer {
    // Placeholder for Visual Composer integration
}
