<?php
namespace Headrix\Settings;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class LivePreview {
    public static function init() {
        // Placeholder: Could use postMessage from Customizer
    }
}
