<?php
namespace Headrix\Performance;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Cache {
    // Placeholder cache helpers using transients can be added here
}
